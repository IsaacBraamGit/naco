import typing
import ioh
import pandas as pd
import os
from implementation import GeneticAlgorithm
from implementation import RandomSearch
#TaskNr is for the task that need to be performed, form 0 to 9
taskNrs = 1
operators=[1,0,0]#first is selection, second recombination, third mutation.
#0 is variant 0, 1 is variant 1


def ruletobase(rule, base):
    newrule=[]
    if rule==0:
        for i in range(pow(base,3)):
            newrule.append(0)
        return newrule
    while rule:
        rule,r=divmod(rule,base)
        newrule.append(r)
    newrule.reverse()
    zeros=[]
    for i in range(pow(base,3)-len(newrule)):
        zeros.append(0)
    return zeros+newrule

class CellularAutomata:
    '''Skeleton CA, you should implement this.'''
    
    def __init__(self, rule_number: int, k: int):
        self.rule=rule_number
        self.k=k

    def __call__(self, c0: typing.List[int], t: int) -> typing.List[int]:
        '''Evaluate for T timesteps. Return Ct for a given C0.'''
        ct=c0[:]
        k=self.k
        rule=self.rule
        ruleinbase=ruletobase(rule,k)
        for timestep in range(t):
            c0=ct[:]
            ruleindex=4
            for b in range(k-1,-1,-1):
                for c in range(k-1,-1,-1):
                    if c0[0]==b and c0[1]==c:
                        ct[0]=ruleinbase[ruleindex]
                    ruleindex+=1
            for i in range(len(c0)-2):
                ruleindex=0
                for a in range(k-1,-1,-1):
                    for b in range(k-1,-1,-1):
                        for c in range(k-1,-1,-1):
                            if c0[i]==a and c0[i+1]==b and c0[i+2]==c:
                                ct[i+1]=ruleinbase[ruleindex]
                            ruleindex+=1
            ruleindex=1
            for a in range(k-1,-1,-1):
                for b in range(k-1,-1,-1):
                    if c0[len(c0)-2]==a and c0[len(c0)-1]==b:
                        ct[len(c0)-1]=ruleinbase[ruleindex]
                    ruleindex+=2
        return ct

def readCsvData(lineNr):

    direct = os.path.abspath(os.getcwd())
    file = direct + "/ca_input.csv"
    df = pd.read_csv (file)


    ct = df['CT'][lineNr]
    ct = ct.replace(" ", "")
    ct= ct[1:-1]
    ct = ct.split(',')
    ct = [int(i) for i in ct]
    rule = df['rule #'][lineNr]
    t = df['T'][lineNr]
    k = df['k'][lineNr]
    global bits 
    
    
    if k.item() == 3:
        #print("k = 3")
        bits= False
    else:
        bits = True

    #print(ct,rule,t,k)
    
    return ct,rule,t,k

# Simple algorithem that shows the % of simulare bits
def objective_function(c0_prime: typing.List[int]) -> float:
    '''Skeleton objective function. You should implement a method
    which computes a similarity measure between c0_prime a suggested by your
    GA, with the true c0 state for the ct state given in the sup. material. '''


    ca = CellularAutomata(rule,k)
    ct_prime = ca(c0_prime, t)

    # simularity is score out of 1.0(1.0 is fully the same)
    simulareBits = 0
    differentBits = 0

    for bit in range(0,len(ct_prime)):
        if ct_prime[bit] == ct[bit]:
            simulareBits +=1
        else:
            differentBits +=1
    simularity = simulareBits/(simulareBits+differentBits)

    #print("simularity obj func 1: ")
    #print(simularity)  
    global best_score
    if simularity > best_score:
        best_score = simularity
    return simularity

# Simple algorithem that shows how alike the bits are accoring to total nr of the same bits(not accounting for order)
def objective_function2(c0_prime: typing.List[int]) -> float:
    '''Skeleton objective function. You should implement a method
    which computes a similarity measure between c0_prime a suggested by your
    GA, with the true c0 state for the ct state given in the sup. material. '''

    #TaskNr is for the task that need to be performed, form 0 to 9
    #ct, rule, t, k = readCsvData(taskNr)
    # Given by the sup. material 

    ca = CellularAutomata(rule,k)
    ct_prime = ca(c0_prime, t)

    #different class bits in ct_prime
    BitsZero_ct_prime = 0
    BitsOne_ct_prime = 0
    BitsTwo_ct_prime = 0
    
    #different class bits in ct
    BitsZero_ct = 0
    BitsOne_ct = 0
    BitsTwo_ct = 0
    
    for bit in range(0,len(ct_prime)):
        if ct_prime[bit] == 0:
            BitsZero_ct_prime +=1
        elif ct_prime[bit] == 1:
            BitsOne_ct_prime +=1
        else:
            BitsTwo_ct_prime += 1
           
        if ct[bit] == 0:
            BitsZero_ct +=1
        elif ct[bit] == 1:
            BitsOne_ct +=1
        else:
            BitsTwo_ct += 1
    
    simularity = len(ct_prime)*3-abs(BitsZero_ct_prime - BitsZero_ct)-abs(BitsOne_ct_prime - BitsOne_ct)-abs(BitsTwo_ct_prime - BitsTwo_ct)
    #print("simularity obj func 2: ")
    #print(len(ct_prime))
    simularity += 100* objective_function(c0_prime)
    #print(simularity)     
    #simularity is from 0 to 280    
    global best_score
    if simularity > best_score:
        best_score = simularity
    return simularity
        
def example(i):
    '''An example of wrapping a objective function in ioh and collecting data
    for inputting in the analyzer.'''
    algorithm = GeneticAlgorithm()
    #algorithm = RandomSearch()
   
    # Wrap objective_function as an ioh problem
    problem = ioh.problem.wrap_integer_problem(
            objective_function2,
            "objective_function2",
            60, 
            ioh.OptimizationType.Maximization,
            ioh.IntegerConstraint([0]*60, [1]*60)
    )
    # Attach a logger to the problem
    logger = ioh.logger.Analyzer(store_positions=True)
    problem.attach_logger(logger)

    # run your algoritm on the problem
    algorithm(problem, bits,operators)
    #for random:
    #algorithm(problem, bits)


if __name__ == '__main__':
    scores = []
    iterations = []
    global best_score
    global best_iterations
    #{0,1,2,5,6,7}
    for i in {1}:
        best_score = 0
        print(i)
        global ct, rule, t, k
        ct, rule, t, k = readCsvData(i)
        example(i)
        scores.append(best_score)

        print(best_score)
    print(scores)
    
    
    
    
    
    
