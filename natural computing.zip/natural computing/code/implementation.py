'''This file contains a skeleton implementation for the practical assignment 
for the NACO 21/22 course. 

Your Genetic Algorithm should be callable like so:
    >>> problem = ioh.get_problem(...)
    >>> ga = GeneticAlgorithm(...)
    >>> ga(problem)

In order to ensure this, please inherit from the provided Algorithm interface,
in a similar fashion as the RandomSearch Example:
    >>> class GeneticAlgorithm(Algorithm):
    >>>     ...

Please be sure to use don't change this name (GeneticAlgorithm) for your implementation.

If you override the constructor in your algoritm code, please be sure to 
call super().__init__, in order to correctly setup the interface. 

Only use keyword arguments for your __init__ method. This is a requirement for the
test script to properly evaluate your algoritm.
'''

import ioh
import random
from algorithm import Algorithm


"""
Parameters:
"""
iterations = 250 #takes value from 0 to sys.maxint, but becarefull that iterations * populationSize < 50.000
populationSize = 100 #population size takes all values (from 4 to sys.maxint)(make sure there are enough for reproduction, so 2 >= populationSize/SizeOfTournament)
#SurvivalRate = 20 # % of population that survives a thanos snap
SizeOfTournament = 2 #can take all values (from 2 to sys.maxint) 
mutationRate = 30 # % out of 100
offspringAmount = 50 #the amount of offspring that gets created in recombination. Can be anything from 0 to sys.maxint
 
class RandomSearch(Algorithm):
    '''An example of Random Search.'''

    def __call__(self, problem: ioh.problem.Integer,bits) -> None:
        self.y_best: float = float("inf")
        self.max_iterations = 10000
        print(self.max_iterations)
        for iteration in range(self.max_iterations):
            # Generate a random bit string
            if(bits):
                x: list[int] = [random.randint(0, 1) for _ in range(problem.meta_data.n_variables)]
            else:
                x: list[int] = [random.randint(0, 2) for _ in range(problem.meta_data.n_variables)]
            #print(x)
            
            # Call the problem in order to get the y value    
            y: float = problem(x)
            #print(y)
            # update the current state
            self.y_best = max(self.y_best, y)
            
            
class GeneticAlgorithm(Algorithm):
    '''A skeleton (minimal) implementation of your Genetic Algorithm.'''
    
    def __call__(self, problem: ioh.problem.Integer, bits,operators) -> None:
        self.bitStrings = []
        self.scores = []
        self.y_best: float = float("inf")
        #make random agents to start with
        for agent in range(populationSize):
            if(bits):
                x: list[int] = [random.randint(0, 1) for _ in range(problem.meta_data.n_variables)]
            else:
                x: list[int] = [random.randint(0, 2) for _ in range(problem.meta_data.n_variables)]
            self.bitStrings.append(x)
            
        for it in range(iterations):
            #print("iteration:")
            #print(it)
            #print("score")
            self.scores = Score(self.bitStrings, problem)
            self.y_best = max(self.scores)
          
            #if(max(self.scores) == 100.0):
                #self.state.optimum_found = True
            if max(self.scores)== 280:
                break
                
            #print("START")
            #print(self.scores)
            #print(self.bitStrings)
            #print("selection")
            self.bitStrings = Selection(self.bitStrings,self.scores)
            #print(self.bitStrings)
        
            #print("recombination")
            #self.bitStrings.extend(Recombination(self.bitStrings,len(self.bitStrings)*(SizeOfTournament)))
            if operators[1]==0:
                self.bitStrings=Recombination0(self.bitStrings,offspringAmount,problem,operators)
            else:
                self.bitStrings=Recombination1(self.bitStrings,offspringAmount,operators)
            #print("mutation")
            if operators[2]==0:
                self.bitStrings = mutation0(self.bitStrings,operators)
            else:
                self.bitStrings = mutation1(self.bitStrings,operators)
           
        
        
def Score(agents, problem):
    scores = []
    for agent in agents:
        y: float = problem(agent)
        scores.append(y)
    return scores
    

def Selection(bitStrings,scores):
    #our implementation of tournament selection
    survivors = []
    #go on till there are no agents left to select.
    while(len(bitStrings) > 0):
        #select competetors
        competetors = []
        
        for selection in range(SizeOfTournament):# for number of participants for tournament
            #if we run out of players we stop selecting:
            if not(SizeOfTournament-len(bitStrings) == len(competetors) and len(competetors) != 0):#we ran out of agents
                rand = random.randint(0, len(bitStrings))-1
                #we don't want doubles in the tournament
                while(rand in competetors):
                    rand = random.randint(0, len(bitStrings))-1
                competetors.append(rand)
        
        #sort so we delete from back    
        competetors.sort(reverse=True)
          
        highscore = -1
        bestPlayer = -1
        #select best competetor
        for comp in competetors:
            if(highscore < scores[comp]):
                highscore = scores[comp]
                bestPlayer = comp
        
        #winner
        survivors.append(bitStrings[bestPlayer])
        
        #remove losers
        for comp in competetors:
            del bitStrings[comp]
            del scores[comp]
    
    while len(survivors)>populationSize:
        survivors.pop(-1)
    i=0
    while len(survivors)<populationSize:
        survivors.append(survivors[i])
        i+=1
        
    return survivors

def recombine(r1,r2):
    bitstring=[]
    for bit in range(len(r1)):
        if random.randint(1,2)==1:
            bitstring.append(r1[bit])
        else:
             bitstring.append(r2[bit])
    return bitstring

def recombineFromAll(bitstrings):
    bitstring=[]
    for bit in range(len(bitstrings[0])):
        bitstring.append(bitstrings[random.randint(0,len(bitstrings)-1)][bit])
    return bitstring
    
def Recombination1(bitstrings,offspringAmount,operators):
    if len(bitstrings)<2:
        return bitstrings
    newBitstrings=[]
    if operators[0]==1:
        newBitstrings.extend(bitstrings)
    for i in range(offspringAmount):
        r1,r2 = random.sample(bitstrings,2)
        newBitstring=recombine(r1,r2)
        newBitstrings.append(newBitstring)
    
    return newBitstrings

def Recombination4(bitstrings,offspringAmount,operators):
    if len(bitstrings)<2:
        return bitstrings
    newBitstrings=[]
    if operators[0]==1:
        newBitstrings.extend(bitstrings)
    for i in range(offspringAmount):
        newBitstring=recombineFromAll(bitstrings)
        newBitstrings.append(newBitstring)
    
    return newBitstrings

def Recombination2(bitstrings,offspringAmount,problem,operators):
    if len(bitstrings)<2:
        return bitstrings
    for i in range(offspringAmount):
        r1,r2 = random.sample(bitstrings,2)
        newBitstring=recombine(r1,r2)
        if operators[0]==0:
            if(problem(newBitstring)>problem(r1)):
                bitstrings[bitstrings.index(r1)]=newBitstring
            elif(problem(newBitstring)>problem(r2)):
                bitstrings[bitstrings.index(r2)]=newBitstring
        else:
            bitstrings.append(newBitstring)
    
    return bitstrings

def Recombination3(bitstrings,offspringAmount,problem,operators):
    if len(bitstrings)<2:
        return bitstrings
    for i in range(offspringAmount):
        newBitstring=recombineFromAll(bitstrings)
        if operators[0]==0:
            for bs in bitstrings:
                if(problem(newBitstring)>problem(bs)):
                    bitstrings[bitstrings.index(bs)]=newBitstring
                    break
        else:
            bitstrings.append(newBitstring)
    
    return bitstrings

def Recombination0(bitstrings,offspringAmount,problem,operators):
    length = len(bitstrings)
    
    for bits in range(length):
        parent1 = random.randint(0, length-1)
        parent2 = random.randint(0, length-1)
        newbits = []
        for i in range(len(bitstrings[bits])):
            if random.randint(0, 100)<49:
                newbits.append(bitstrings[parent1][i])
            elif random.randint(0, 100)<98:
                newbits.append(bitstrings[parent2][i])
            else:
                newbits.append(random.randint(0, 1))
    
        bitstrings.append(newbits)
        

    return bitstrings

def mutation0(bitStrings,operators):
    #Our implementation of swap mutation
    bitStringsBackup=[]
    for bs in bitStrings:
        if(random.randint(0, 100)< mutationRate):
            bitStringsBackup.append(bs)
            random1 = random.randint(0, len(bs)-1)
            random2 = random.randint(0, len(bs)-1)
            copy = bs[random1]
            bs[random1] = bs[random2]
            bs[random2] = copy
            
    if operators[0]==1:
        bitStrings.extend(bitStringsBackup)
    return bitStrings#same size as bitStrings

def mutation1(bitStrings,operators):
    #Our implementation of swap mutation
    bitStringsBackup=[]
    for bs in bitStrings:
        if(random.randint(0, 100)< mutationRate):
            bitStringsBackup.append(bs)
            random1 = random.randint(0, len(bs)-1)
            random2 = random.randint(0, len(bs)-1)
            copy=[]
            if random1<random2:
                randomLow=random1
                randomHigh=random2
            else:
                randomLow=random2
                randomHigh=random1
            for i in range(randomLow,randomHigh+1):
                copy.append(bs[i])
            for i in range(randomLow,randomHigh+1):
                bs[i]=copy[i-randomLow]
    if operators[0]==1:
        bitStrings.extend(bitStringsBackup)
    return bitStrings#same size as bitStrings
        
def main():
    # Set a random seed in order to get reproducible results
    random.seed(42)
    bits = True
    # Instantiate the algoritm, you should replace this with your GA implementation 
    #algorithm = RandomSearch()
    algorithm = GeneticAlgorithm()

    # Get a problem from the IOHexperimenter environment
    problem: ioh.problem.Integer = ioh.get_problem(1, 1, 5, "Integer")
    

    # Run the algoritm on the problem
    algorithm(problem, bits,[0,0,0])

    # Inspect the results
    print("Best solution found:")
    print("".join(map(str, problem.state.current_best.x)))
    print("With an objective value of:", problem.state.current_best.y)
    print()


if __name__ == '__main__':
    main()
